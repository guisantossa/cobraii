
# seed_fake_data.py
import os
import random
from datetime import datetime, timedelta, date, time
from decimal import Decimal
from zoneinfo import ZoneInfo

from faker import Faker

# --- DB session ---
try:
    from app.db.session import SessionLocal
except Exception as e:
    raise SystemExit("Import de SessionLocal falhou. Ajuste 'from app.db.session import SessionLocal' ao seu projeto.") from e

# --- CRUDs / Services ---
# Ajuste os caminhos abaixo se sua árvore for diferente.
try:
    # Usuarios
    from app.services.usuarios import create_usuario
    from app.schemas.usuarios import UsuarioCreate

    # Clientes
    from app.services.clientes import create_cliente
    from app.schemas.clientes import ClienteCreate

    # Cobrancas
    from app.services.cobrancas import create_cobranca
    from app.schemas.cobrancas import CobrancaCreate

    # Faturas
    from app.services.faturas import create_fatura, marcar_fatura_paga
    from app.schemas.faturas import FaturaCreate
    from app.models.enums import FaturaStatusEnum

    # Lembretes
    from app.services.lembretes import criar_lembrete
    from app.schemas.lembretes import LembreteCreate, OffsetItem

    # Models (para consultas pontuais)
    from app.models.faturas import Fatura
    from app.models.cobrancas import Cobranca
except Exception as e:
    raise SystemExit("Imports dos services/schemas/models falharam. Ajuste os paths 'app.services.*', 'app.schemas.*' e 'app.models.*'.") from e

TZ = ZoneInfo("America/Sao_Paulo")

START = date(2024, 9, 14)
END   = date(2025, 9, 13)

# Totais globais
N_USERS       = 50
N_CLIENTES    = 1000      # 20 por usuário
N_FATURAS     = 25000     # 500 por usuário
N_PAGAMENTOS  = 10000     # 200 por usuário
N_LEMBRETES   = 50000     # 1000 por usuário

# Distribuição por usuário
CLIENTES_PER_USER   = N_CLIENTES // N_USERS        # 20
FATURAS_PER_USER    = N_FATURAS // N_USERS         # 500
PAGOS_PER_USER      = N_PAGAMENTOS // N_USERS      # 200
LEMBRETES_PER_USER  = N_LEMBRETES // N_USERS       # 1000

# Estratégia: 50 cobranças por usuário, cada uma com ~10 faturas (para atingir 500 faturas)
COBRANCAS_PER_USER = 50
FATURAS_PER_COBRANCA = max(1, FATURAS_PER_USER // COBRANCAS_PER_USER)  # 10

fake = Faker("pt_BR")
random.seed(42)

def rand_date(start: date, end: date) -> date:
    delta = (end - start).days
    return start + timedelta(days=random.randint(0, max(0, delta)))

def clamp_date(d: date) -> date:
    if d < START:
        return START
    if d > END:
        return END
    return d

def month_series(start_date: date, count: int, jitter_days: int = 5):
    """Gera 'count' datas mensais a partir de start_date com leve jitter."""
    d = start_date
    out = []
    for _ in range(count):
        d = d + timedelta(days=30 + random.randint(-jitter_days, jitter_days))
        out.append(clamp_date(d))
    return out

def create_users(db):
    users = []
    for i in range(N_USERS):
        nome = fake.name()
        email = f"seed{i}@cobraii.test"
        telefone = fake.msisdn()[:13]
        doc = fake.cpf().replace(".", "").replace("-", "")
        senha = "12345678"
        # Usa apenas campos básicos (evita campos extras que possam não existir no seu schema)
        u = create_usuario(
            db,
            UsuarioCreate(
                nome=nome,
                email=email,
                telefone=telefone,
                documento=doc,
                senha=senha,
            ),
        )
        users.append(u)
    return users

def create_clientes_for_user(db, usuario, n=20):
    clientes = []
    for _ in range(n):
        nome = fake.name()
        email = fake.unique.email()
        telefone = fake.msisdn()[:13]
        documento = fake.cpf().replace(".", "").replace("-", "")
        c = create_cliente(
            db,
            usuario_id=usuario.id,
            data=ClienteCreate(
                nome=nome,
                email=email,
                telefone=telefone,
                documento=documento,
            ),
        )
        clientes.append(c)
    return clientes

def create_cobrancas_and_faturas_for_user(db, usuario, clientes):
    # Para cada cobrança, crie a inicial via create_cobranca e complete com faturas mensais
    for i in range(COBRANCAS_PER_USER):
        cliente = random.choice(clientes)
        titulo = f"Mensalidade {i+1:02d}"
        descricao = "Cobrança recorrente (seed)"
        valor = Decimal(str(round(random.uniform(30, 1500), 2)))
        venc_ini = rand_date(START, END)

        c = create_cobranca(
            db,
            usuario_id=usuario.id,
            data=CobrancaCreate(
                titulo=titulo,
                descricao=descricao,
                cliente_id=cliente.id,
                cliente_nome_avulso=None,
                valor=valor,
                recorrencia="mensal",
                vencimento=venc_ini,
            ),
        )

        # faturas adicionais para essa cobrança (além da inicial criada pelo service)
        series = month_series(venc_ini, max(0, FATURAS_PER_COBRANCA - 1))
        for v in series:
            if v < START or v > END:
                continue
            create_fatura(
                db,
                usuario_id=usuario.id,
                data=FaturaCreate(
                    cobranca_id=c.id,
                    valor=valor,
                    vencimento=v,
                    data_pagamento=None,
                    status="pendente",
                ),
            )

def fetch_all_faturas_ids(db, usuario_id):
    return [fid for (fid,) in db.query(Fatura.id).filter(Fatura.usuario_id == usuario_id).all()]

def marcar_pagamentos(db, usuario, n_pagamentos: int):
    fatura_ids = fetch_all_faturas_ids(db, usuario.id)
    if not fatura_ids:
        return
    picks = random.sample(fatura_ids, k=min(n_pagamentos, len(fatura_ids)))
    for fid in picks:
        f = db.query(Fatura).filter(Fatura.id == fid, Fatura.usuario_id == usuario.id).first()
        if not f or f.data_pagamento:
            continue
        pay_date = f.vencimento + timedelta(days=random.randint(0, 20))
        if pay_date > END:
            pay_date = END
        marcar_fatura_paga(db, usuario_id=usuario.id, fatura_id=fid, data_pagamento=pay_date)

def create_lembretes(db, usuario, clientes, n_lembretes: int):
    # 60% baseados em fatura (offsets), 40% periódicos (RRULE)
    qty_fatura = int(n_lembretes * 0.6)
    qty_periodic = n_lembretes - qty_fatura

    # 1) Fatura-based
    faturas_ids = fetch_all_faturas_ids(db, usuario.id)
    random.shuffle(faturas_ids)
    faturas_pick = faturas_ids[:qty_fatura]

    canais = ["whatsapp", "email", "sms"]
    for fid in faturas_pick:
        f = db.query(Fatura).filter(Fatura.id == fid, Fatura.usuario_id == usuario.id).first()
        if not f:
            continue
        c = db.query(Cobranca).filter(Cobranca.id == f.cobranca_id).first()
        cliente_id = c.cliente_id if c else random.choice(clientes).id

        # dtstart tz-aware na data de vencimento às 09:00
        dtstart = datetime.combine(f.vencimento, time(9, 0)).replace(tzinfo=TZ)

        offsets = [
            OffsetItem(when="before", days=random.choice([7, 3, 1]), hora=random.choice(["09:00","14:00","18:00"]), condicao=random.choice(["sempre","se_nao_cumprido"])),
            OffsetItem(when="after", days=random.choice([1, 3]), hora=random.choice(["09:00","14:00","18:00"]), condicao="se_nao_cumprido"),
        ]

        criar_lembrete(
            db,
            usuario_id=usuario.id,
            data=LembreteCreate(
                cliente_id=cliente_id,
                fatura_id=fid,
                titulo=f"Lembrete de Fatura #{fid}",
                corpo="Olá {{cliente.primeiro_nome}}, sua fatura vence em {{fatura.vencimento}} no valor de R$ {{fatura.valor}}.",
                canal=random.choice(canais),
                event_date=None,
                rrule=None,
                dtstart=dtstart,
                tz="America/Sao_Paulo",
                offsets=offsets,
                condicao=random.choice(["sempre","se_nao_cumprido"]),
                meta=None,
                ativa=True,
            ),
        )

    # 2) Periódicos com RRULE (ex.: semanal ou mensal)
    for _ in range(qty_periodic):
        cliente = random.choice(clientes)
        start_date = rand_date(START, END)
        dtstart = datetime.combine(start_date, time(10, 0)).replace(tzinfo=TZ)
        if random.random() < 0.5:
            rrule = "FREQ=MONTHLY;COUNT=12"
            titulo = "Lembrete mensal"
        else:
            rrule = "FREQ=WEEKLY;COUNT=12"
            titulo = "Lembrete semanal"

        criar_lembrete(
            db,
            usuario_id=usuario.id,
            data=LembreteCreate(
                cliente_id=cliente.id,
                fatura_id=None,
                titulo=titulo,
                corpo="Oi {{cliente.primeiro_nome}}, este é um lembrete periódico.",
                canal=random.choice(canais),
                event_date=None,
                rrule=rrule,
                dtstart=dtstart,
                tz="America/Sao_Paulo",
                offsets=None,
                condicao="sempre",
                meta=None,
                ativa=True,
            ),
        )

def main():
    # Opcional: durante seed, permitir desligar auditorias em services (se implementado)
    os.environ.setdefault("SEED_NO_AUDIT", "1")

    db = SessionLocal()
    try:
        print("[1/5] Criando usuários...")
        users = create_users(db)

        for idx, u in enumerate(users, 1):
            print(f"[2/5] ({idx}/{len(users)}) Criando clientes do usuário {u.email}...")
            clientes = create_clientes_for_user(db, u, CLIENTES_PER_USER)

            print(f"[3/5] ({idx}/{len(users)}) Criando cobranças e faturas...")
            create_cobrancas_and_faturas_for_user(db, u, clientes)

            print(f"[4/5] ({idx}/{len(users)}) Marcando pagamentos...")
            marcar_pagamentos(db, u, PAGOS_PER_USER)

            print(f"[5/5] ({idx}/{len(users)}) Criando lembretes...")
            create_lembretes(db, u, clientes, LEMBRETES_PER_USER)

        print("Seed finalizado.")
    finally:
        db.close()

if __name__ == "__main__":
    main()
