
# seed_fake_data.py
"""
Seeder para popular o banco com dados realistas.
Requisitos:
  - Python 3.10+
  - pip install faker passlib[bcrypt] python-dateutil python-dotenv sqlalchemy

Uso:
  DATABASE_URL=postgresql+psycopg2://user:pass@localhost:5432/dbname \      python seed_fake_data.py --usuarios 10 --clientes 100 --cobrancas 1000 --lembretes 10000 --templates 500 --meses 6

Notas:
  - O script não dá drop/create nas tabelas; apenas insere.
  - Usa batches para performance.
  - Para evitar duplicar, por padrão falha se já houver registros (passe --force para ignorar).
"""

import os
import sys
import math
import random
from uuid import uuid4
from datetime import datetime, timedelta, date, time
from typing import List

from faker import Faker
from passlib.hash import bcrypt
from dateutil.relativedelta import relativedelta
from dotenv import load_dotenv

from sqlalchemy import create_engine, func, select, text
from sqlalchemy.orm import sessionmaker

# ===== Ajuste de import path para permitir "from app.*" quando rodado pela raiz =====
# Ex: backend/ (raiz) com app/ e este arquivo lado a lado ou 1 nível acima/below
ROOTS = [os.getcwd(), os.path.dirname(os.path.abspath(__file__)), os.path.join(os.getcwd(), "backend")]
for r in ROOTS:
    if r not in sys.path:
        sys.path.append(r)

# ===== Imports de models =====
from app.models.models import Usuario, Cliente
from app.models.cobrancas import Cobranca
from app.models.faturas import Fatura
from app.models.lembretes import Lembrete
from app.models.templates import TemplateMensagem
from app.models.enums import RecorrenciaEnum, CanalLembreteEnum, FaturaStatusEnum

import argparse

def chunked(iterable, size):
    for i in range(0, len(iterable), size):
        yield iterable[i:i+size]

def rand_datetime_within(months_back: int) -> datetime:
    """Retorna um datetime aleatório dos últimos N meses até hoje."""
    now = datetime.now()
    earliest = now - relativedelta(months=months_back)
    total_seconds = int((now - earliest).total_seconds())
    offset = random.randint(0, total_seconds)
    return earliest + timedelta(seconds=offset)

def rand_date_within(months_back: int) -> date:
    return rand_datetime_within(months_back).date()

def seed(args):
    load_dotenv()
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        raise SystemExit("Defina DATABASE_URL no ambiente ou em .env")

    fake = Faker("pt_BR")
    random.seed(42)

    engine = create_engine(database_url, pool_pre_ping=True, future=True)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    with SessionLocal() as db:
        # sanity check
        try:
            db.execute(text("SELECT 1"))
        except Exception as e:
            raise SystemExit(f"Falha ao conectar no banco: {e}")

        # Verificações de existência
        existing_users = db.scalar(select(func.count(Usuario.id)))
        existing_clients = db.scalar(select(func.count(Cliente.id)))
        existing_cobrancas = db.scalar(select(func.count(Cobranca.id)))
        existing_lembretes = db.scalar(select(func.count(Lembrete.id)))
        existing_templates = db.scalar(select(func.count(TemplateMensagem.id)))

        if not args.force and any([existing_users, existing_clients, existing_cobrancas, existing_lembretes, existing_templates]):
            raise SystemExit(
                f"Já existem registros (usuarios={existing_users}, clientes={existing_clients}, cobrancas={existing_cobrancas}, lembretes={existing_lembretes}, templates={existing_templates}). "
                "Rode com --force para inserir mesmo assim."
            )

        # ===== 1) Usuários =====
        usuarios: List[Usuario] = []
        for i in range(args.usuarios):
            nome = fake.name()
            email = f"{fake.user_name()}.{i}@example.com"
            telefone = fake.msisdn()
            documento = fake.cpf()
            senha_hash = bcrypt.hash("cobraii123")
            usuarios.append(Usuario(
                id=uuid4(),
                nome=nome,
                email=email,
                telefone=telefone,
                senha_hash=senha_hash,
                documento=documento
            ))

        for batch in chunked(usuarios, 200):
            db.add_all(batch)
            db.flush()  # para garantir ids disponíveis

        # Refresh usuários com IDs
        db.commit()
        usuarios = db.execute(select(Usuario)).scalars().all()

        # ===== 2) Clientes =====
        clientes: List[Cliente] = []
        for i in range(args.clientes):
            u = random.choice(usuarios)
            clientes.append(Cliente(
                id=uuid4(),
                usuario_id=u.id,
                nome=fake.name(),
                email=fake.safe_email(),
                telefone=fake.msisdn(),
                documento=(fake.cpf() if random.random() < 0.7 else fake.cnpj())
            ))
        for batch in chunked(clientes, 500):
            db.add_all(batch)
            db.flush()
        db.commit()

        # Obter clientes com ids
        clientes = db.execute(select(Cliente)).scalars().all()

        # ===== 3) Templates =====
        canais = list(CanalLembreteEnum)
        templates: List[TemplateMensagem] = []
        placeholder_sets = [
            ["Cliente", "Vencimento", "Valor"],
            ["Cliente", "LinkPagamento"],
            ["Cliente", "Descricao"],
            ["Cliente", "Periodo"],
            ["Cliente", "ContatoSuporte"]
        ]
        for _ in range(args.templates):
            u = random.choice(usuarios)
            placeholders = random.choice(placeholder_sets)
            titulo = f"Template {fake.word().capitalize()} {fake.color_name()}"
            corpo = (
                "Olá {{Cliente}}, tudo bem?\n"
                "Este é um lembrete sobre {{Descricao}}. "
                "Vencimento: {{Vencimento}}. Valor: R$ {{Valor}}. "
                "Link: {{LinkPagamento}}."
            )
            templates.append(TemplateMensagem(
                id=uuid4(),
                usuario_id=u.id,
                titulo=titulo[:120],
                corpo=corpo,
                placeholders=placeholders,
                canal=random.choice(canais),
                criado_em=rand_datetime_within(args.meses),
                atualizado_em=rand_datetime_within(args.meses),
            ))
        for batch in chunked(templates, 500):
            db.add_all(batch)
            db.flush()
        db.commit()

        # ===== 4) Cobranças + Faturas (movimentações em 6 meses) =====
        cobrancas: List[Cobranca] = []
        faturas: List[Fatura] = []

        recorrencias = [RecorrenciaEnum.unica, RecorrenciaEnum.mensal, RecorrenciaEnum.semanal]
        for i in range(args.cobrancas):
            u = random.choice(usuarios)
            c = random.choice(clientes)
            valor = round(random.uniform(30, 3000), 2)
            rec = random.choice(recorrencias)
            venc = rand_date_within(args.meses)
            titulo = random.choice(["Mensalidade", "Serviço", "Assinatura", "Manutenção", "Consultoria"])
            descricao = fake.sentence(nb_words=8)

            cobranca = Cobranca(
                id=uuid4(),
                usuario_id=u.id,
                titulo=titulo,
                descricao=descricao,
                cliente_id=c.id,
                cliente_nome_avulso=None if random.random() < 0.9 else c.nome,
                valor=valor,
                recorrencia=rec,
                vencimento=venc,
                data_criacao=rand_datetime_within(args.meses),
                data_atualizacao=rand_datetime_within(args.meses),
            )
            cobrancas.append(cobranca)

            status = random.choices(
                population=[FaturaStatusEnum.pendente, FaturaStatusEnum.pago, FaturaStatusEnum.atrasado, FaturaStatusEnum.cancelado],
                weights=[0.45, 0.35, 0.15, 0.05],
                k=1
            )[0]
            data_pagamento = None
            if status == FaturaStatusEnum.pago:
                data_pagamento = min(date.today(), venc + timedelta(days=random.randint(0, 10)))

            faturas.append(Fatura(
                id=uuid4(),
                usuario_id=u.id,
                cobranca_id=cobranca.id,
                valor=valor,
                vencimento=venc,
                data_pagamento=data_pagamento,
                status=status,
                data_criacao=rand_datetime_within(args.meses),
                data_atualizacao=rand_datetime_within(args.meses),
            ))

        for batch in chunked(cobrancas, 500):
            db.add_all(batch)
            db.flush()
        for batch in chunked(faturas, 500):
            db.add_all(batch)
            db.flush()
        db.commit()

        # ===== 5) Lembretes =====
        canais = list(CanalLembreteEnum)
        lembretes: List[Lembrete] = []

        faturas_all = db.execute(select(Fatura.cobranca_id, Fatura.id, Fatura.vencimento)).all()

        for i in range(args.lembretes):
            u = random.choice(usuarios)
            c = random.choice(clientes)
            canal = random.choice(canais)
            titulo = random.choice([
                "Lembrete de pagamento",
                "Aviso de vencimento",
                "Confirmação de agendamento",
                "Mensagem de boas-vindas",
                "Atualização de cadastro"
            ])
            corpo = fake.paragraph(nb_sentences=2)
            event_date = rand_date_within(args.meses) if random.random() < 0.3 else None

            fatura_id = None
            offsets = None
            if random.random() < 0.4 and faturas_all:
                fr = random.choice(faturas_all)
                fatura_id = fr.id
                offsets = [
                    {"when": "before", "days": random.choice([1, 2, 3, 5]), "hora": random.choice(["09:00","14:00","18:00"]), "condicao": random.choice(["sempre", "se_nao_cumprido"])}
                ]

            rrule = None
            dtstart = None
            tz = "America/Sao_Paulo"
            if event_date and random.random() < 0.2:
                rrule = "FREQ=YEARLY;BYMONTH=%d;BYMONTHDAY=%d" % (event_date.month, event_date.day)
                dtstart = datetime.combine(event_date, time(9, 0))

            lembretes.append(Lembrete(
                id=uuid4(),
                usuario_id=u.id,
                cliente_id=c.id,
                fatura_id=fatura_id,
                titulo=titulo,
                corpo=corpo,
                canal=canal,
                event_date=event_date,
                rrule=rrule,
                dtstart=dtstart,
                tz=tz,
                offsets=offsets,
                condicao=random.choice(["sempre", "se_nao_cumprido"]),
                ativa=True,
                proxima_execucao_at=None,
                meta=None,
            ))

        for batch in chunked(lembretes, 1000):
            db.add_all(batch)
            db.flush()
        db.commit()

        print("OK!")
        print(f"Inseridos -> usuarios={len(usuarios)}, clientes={len(clientes)}, cobrancas={len(cobrancas)}, faturas={len(faturas)}, lembretes={len(lembretes)}, templates={len(templates)}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Seeder de dados para Cobraii.")
    parser.add_argument("--usuarios", type=int, default=10)
    parser.add_argument("--clientes", type=int, default=100)
    parser.add_argument("--cobrancas", type=int, default=1000)
    parser.add_argument("--lembretes", type=int, default=10000)
    parser.add_argument("--templates", type=int, default=500)
    parser.add_argument("--meses", type=int, default=6, help="Janela de meses passados para gerar datas")
    parser.add_argument("--force", action="store_true", help="Insere mesmo que já existam registros")
    args = parser.parse_args()
    seed(args)
