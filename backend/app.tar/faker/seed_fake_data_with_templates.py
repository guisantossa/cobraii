
# seed_fake_data_with_templates.py
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import random
from datetime import datetime, timedelta, date, time
from decimal import Decimal
from zoneinfo import ZoneInfo
from faker import Faker

try:
    from app.db.session import SessionLocal
except Exception as e:
    raise SystemExit(f"Import de SessionLocal falhou ({type(e).__name__}): {e}") from e

try:
    from app.crud.usuarios import create_usuario
    from app.schemas.usuarios import UsuarioCreate

    from app.crud.clientes import create_cliente
    from app.schemas.clientes import ClienteCreate

    from app.crud.cobrancas import create_cobranca
    from app.schemas.cobrancas import CobrancaCreate

    from app.crud.faturas import create_fatura, marcar_fatura_paga
    from app.schemas.faturas import FaturaCreate

    from app.crud.lembretes import criar_lembrete
    from app.schemas.lembretes import LembreteCreate, OffsetItem

    from app.crud.templates import create_template
    from app.schemas.templates import TemplateCreate

    from app.models.faturas import Fatura
    from app.models.cobrancas import Cobranca
except Exception as e:
    raise SystemExit(f"Imports dos services/schemas/models falharam ({type(e).__name__}): {e}. Ajuste os paths 'app.services.*', 'app.schemas.*' e 'app.models.*'.") from e

TZ = ZoneInfo("America/Sao_Paulo")
START = date(2024, 9, 14)
END   = date(2025, 9, 13)

N_USERS       = 10
N_CLIENTES    = 500
N_FATURAS     = 6000
N_PAGAMENTOS  = 5000
N_LEMBRETES   = 1500
N_TEMPLATES   = 100

CLIENTES_PER_USER   = N_CLIENTES // N_USERS
FATURAS_PER_USER    = N_FATURAS // N_USERS
PAGOS_PER_USER      = N_PAGAMENTOS // N_USERS
LEMBRETES_PER_USER  = N_LEMBRETES // N_USERS
TEMPLATES_PER_USER  = max(1, N_TEMPLATES // N_USERS)

COBRANCAS_PER_USER = 50
FATURAS_PER_COBRANCA = max(1, FATURAS_PER_USER // COBRANCAS_PER_USER)

fake = Faker("pt_BR")
random.seed(42)

def rand_date(start: date, end: date) -> date:
    delta = (end - start).days
    return start + timedelta(days=random.randint(0, max(0, delta)))

def clamp_date(d: date) -> date:
    return max(min(d, END), START)

def month_series(start_date: date, count: int, jitter_days: int = 5):
    d = start_date
    out = []
    for _ in range(count):
        d = d + timedelta(days=30 + random.randint(-jitter_days, jitter_days))
        out.append(clamp_date(d))
    return out

def create_users(db):
    users = []
    for i in range(N_USERS):
        u = create_usuario(
            db,
            UsuarioCreate(
                nome=fake.name(),
                email=f"seed{i}@cobraii.com.br",
                telefone=fake.msisdn()[:13],
                documento=fake.cpf().replace(".", "").replace("-", ""),
                senha="12345678",
            ),
        )
        users.append(u)
    return users

def create_clientes_for_user(db, usuario, n=20):
    return [
        create_cliente(
            db,
            usuario_id=usuario.id,
            data=ClienteCreate(
                nome=fake.name(),
                email=fake.unique.email(),
                telefone=fake.msisdn()[:13],
                documento=fake.cpf().replace(".", "").replace("-", ""),
            ),
        )
        for _ in range(n)
    ]

def create_cobrancas_and_faturas_for_user(db, usuario, clientes):
    for _ in range(COBRANCAS_PER_USER):
        cliente = random.choice(clientes)
        valor = round(random.uniform(30, 1500), 2)  # float for audit-safe JSON
        venc_ini = rand_date(START, END)
        c = create_cobranca(
            db,
            usuario_id=usuario.id,
            data=CobrancaCreate(
                titulo="Mensalidade",
                descricao="Cobrança recorrente (seed)",
                cliente_id=cliente.id,
                cliente_nome_avulso=None,
                valor=valor,
                recorrencia="mensal",
                vencimento=venc_ini,
            ),
        )
        for v in month_series(venc_ini, FATURAS_PER_COBRANCA - 1):
            create_fatura(
                db,
                usuario_id=usuario.id,
                data=FaturaCreate(
                    usuario_id=usuario.id,
                    cobranca_id=c.id,
                    valor=valor,
                    vencimento=v,
                    data_pagamento=None,
                    status="pendente",
                ),
            )
        

def fetch_all_faturas_ids(db, usuario_id):
    return [fid for (fid,) in db.query(Fatura.id).filter(Fatura.usuario_id == usuario_id).all()]

def marcar_pagamentos(db, usuario, n_pagamentos):
    fatura_ids = fetch_all_faturas_ids(db, usuario.id)
    if not fatura_ids:
        return
    picks = random.sample(fatura_ids, k=min(n_pagamentos, len(fatura_ids)))
    for fid in picks:
        f = db.query(Fatura).filter(Fatura.id == fid, Fatura.usuario_id == usuario.id).first()
        if not f or f.data_pagamento:
            continue
        pay_date = min(f.vencimento + timedelta(days=random.randint(0, 20)), END)
        marcar_fatura_paga(db, usuario_id=usuario.id, fatura_id=fid, data_pagamento=pay_date)

def create_lembretes(db, usuario, clientes, n_lembretes):
    qty_fatura = int(n_lembretes * 0.6)
    qty_periodic = n_lembretes - qty_fatura
    faturas_ids = fetch_all_faturas_ids(db, usuario.id)
    random.shuffle(faturas_ids)
    faturas_pick = faturas_ids[:qty_fatura]
    canais = ["whatsapp", "email", "sms"]

    for fid in faturas_pick:
        f = db.query(Fatura).filter(Fatura.id == fid, Fatura.usuario_id == usuario.id).first()
        if not f:
            continue
        c = db.query(Cobranca).filter(Cobranca.id == f.cobranca_id).first()
        cliente_id = c.cliente_id if c else random.choice(clientes).id
        dtstart = datetime.combine(f.vencimento, time(9, 0), tzinfo=TZ)
        criar_lembrete(
            db,
            usuario_id=usuario.id,
            data=LembreteCreate(
                cliente_id=cliente_id,
                fatura_id=fid,
                titulo=f"Lembrete de Fatura #{fid}",
                corpo="Olá {{cliente.primeiro_nome}}, sua fatura vence em {{fatura.vencimento}} no valor de R$ {{fatura.valor}}.",
                canal=random.choice(canais),
                event_date=None,
                rrule=None,
                dtstart=dtstart,
                tz="America/Sao_Paulo",
                offsets=[
                    OffsetItem(when="before", days=3, hora="09:00", condicao="sempre")
                ],
                condicao="sempre",
                meta=None,
                ativa=True,
            ),
        )

    for _ in range(qty_periodic):
        cliente = random.choice(clientes)
        start_date = rand_date(START, END)
        dtstart = datetime.combine(start_date, time(10, 0), tzinfo=TZ)
        rrule = random.choice(["FREQ=MONTHLY;COUNT=12", "FREQ=WEEKLY;COUNT=12"])
        criar_lembrete(
            db,
            usuario_id=usuario.id,
            data=LembreteCreate(
                cliente_id=cliente.id,
                fatura_id=None,
                titulo="Lembrete periódico",
                corpo="Oi {{cliente.primeiro_nome}}, este é um lembrete periódico.",
                canal=random.choice(canais),
                event_date=None,
                rrule=rrule,
                dtstart=dtstart,
                tz="America/Sao_Paulo",
                offsets=None,
                condicao="sempre",
                meta=None,
                ativa=True,
            ),
        )

def create_templates_for_user(db, usuario, n_templates):
    categorias = ["cobranca", "lembrete", "promocional"]
    canais = ["whatsapp", "email", "sms"]
    base_corpos = [
        "Olá {{cliente.primeiro_nome}}, sua fatura de {{fatura.valor}} vence em {{fatura.vencimento}}.",
        "Oi {{cliente.nome}}, recebemos seu pagamento de {{fatura.valor}}. Obrigado!",
        "Olá {{cliente.primeiro_nome}}, notamos atraso na fatura de {{fatura.valor}}. Pode verificar?",
        "Promo: {{cliente.primeiro_nome}}, descontos ativos até {{hoje}}. Responda este Whats.",
    ]
    for _ in range(n_templates):
        create_template(
            db,
            usuario_id=usuario.id,
            data=TemplateCreate(
                titulo=f"Template {random.choice(categorias)}",
                categoria=random.choice(categorias),
                canal=random.choice(canais),
                corpo=random.choice(base_corpos),
                ativo=True,
                meta=None,
            ),
        )

def main():
    db = SessionLocal()
    try:
        users = create_users(db)
        for u in users:
            clientes = create_clientes_for_user(db, u, CLIENTES_PER_USER)
            create_cobrancas_and_faturas_for_user(db, u, clientes)
            marcar_pagamentos(db, u, PAGOS_PER_USER)
            create_lembretes(db, u, clientes, LEMBRETES_PER_USER)
            create_templates_for_user(db, u, TEMPLATES_PER_USER)
        print("Seed finalizado com templates.")
    finally:
        db.close()

if __name__ == "__main__":
    main()
