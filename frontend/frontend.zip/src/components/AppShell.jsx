/* FILE: src/components/AppShell.jsx — igual ao mockup */
import { NavLink, Link, Outlet } from 'react-router-dom'
import { LayoutGrid, Users, CreditCard, Bell } from 'lucide-react'

export default function AppShell() {
  return (
    <div className="min-h-screen grid grid-cols-[240px_1fr] bg-[var(--bg)]">
      {/* Sidebar */}
      <aside className="bg-slate-900 text-white flex flex-col">
        <div className="p-4 border-b border-slate-700">
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-[var(--primary)] to-[var(--secondary)] w-9 h-9 rounded-lg flex items-center justify-center font-bold">
              C
            </div>
            <span className="font-bold text-lg">Cobraii</span>
          </Link>
        </div>
        <nav className="flex-1 p-2 space-y-1">
          <SideItem to="/dashboard" icon={<LayoutGrid size={18} />}>Dashboard</SideItem>
          <SideItem to="/clientes" icon={<Users size={18} />}>Clientes</SideItem>
          <SideItem to="/cobrancas" icon={<CreditCard size={18} />}>Cobranças</SideItem>
          <SideItem to="/lembretes" icon={<Bell size={18} />}>Lembretes</SideItem>
        </nav>
      </aside>

      {/* Main */}
      <div className="flex flex-col min-h-screen">
        <header className="h-14 bg-white border-b border-[var(--border)] flex items-center px-6">
          <h1 className="font-bold">Painel</h1>
        </header>
        <main className="p-6 flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

function SideItem({ to, icon, children }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center gap-3 px-3 py-2 rounded-md hover:bg-slate-800 transition ${isActive ? 'bg-slate-800' : ''}`
      }
    >
      {icon}
      <span>{children}</span>
    </NavLink>
  )
}
