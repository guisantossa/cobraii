import { useEffect, useState } from 'react'

/** Tipo de lembrete (UX-friendly)
 * Valores enviados ao backend: 'cobranca' | 'aviso' | 'documento' | 'agendamento' | 'outros'
 */
export default function TipoSelect({
  value,
  onChange,
  outroDescricao,
  onOutroDescricaoChange,
  options,
}) {
  const defaultOptions = ['cobranca', 'aviso', 'documento', 'agendamento', 'outros']
  const [tipo, setTipo] = useState(value || 'cobranca')

  useEffect(() => {
    setTipo(value || 'cobranca')
  }, [value])

  const handleChange = (e) => {
    const v = e.target.value
    setTipo(v)
    onChange && onChange(v)
  }

  const label = (opt) => {
    switch (opt) {
      case 'cobranca': return 'Cobrança'
      case 'aviso': return 'Aviso'
      case 'documento': return 'Documento'
      case 'agendamento': return 'Agendamento'
      case 'outros': return 'Outro canal'
      default: return opt
    }
  }

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-slate-700">Tipo de lembrete</label>
      <select
        className="w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
        value={tipo}
        onChange={handleChange}
      >
        {(options || defaultOptions).map((opt) => (
          <option key={opt} value={opt}>{label(opt)}</option>
        ))}
      </select>

      {tipo === 'outros' && (
        <div className="mt-2">
          <label className="block text-sm text-slate-700">Descreva o canal (opcional)</label>
          <input
            type="text"
            className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
            placeholder="Ex.: Telegram, Ligação, Notificação interna..."
            value={outroDescricao || ''}
            onChange={(e) => onOutroDescricaoChange && onOutroDescricaoChange(e.target.value)}
          />
        </div>
      )}
    </div>
  )
}
