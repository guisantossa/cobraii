import { useEffect, useMemo, useState } from 'react'
import { RRule } from 'rrule'

/**
 * Builder visual para RRULE (RFC 5545)
 *
 * Props:
 *  - value: string | undefined (RRULE atual)
 *  - onChange: (rruleString: string) => void
 */
export default function RRuleBuilder({ value, onChange }) {
  const [enabled, setEnabled] = useState(Boolean(value))
  const [freq, setFreq] = useState('WEEKLY')
  const [interval, setInterval] = useState(1)
  const [byday, setByday] = useState([]) // ex.: ['MO','WE']
  const [dtstart, setDtstart] = useState('') // datetime-local string
  const [until, setUntil] = useState('') // datetime-local string
  const [count, setCount] = useState('')

  // Hidrata de value inicial (se existir)
  useEffect(() => {
    if (!value) return
    try {
      const rule = RRule.fromString(value)
      setEnabled(true)
      setFreq(RRule.FREQUENCIES[rule.options.freq])
      setInterval(rule.options.interval || 1)
      setByday((rule.options.byweekday || []).map((w) => w.toString().slice(0, 2).toUpperCase()))
      if (rule.options.dtstart) setDtstart(toLocal(rule.options.dtstart))
      if (rule.options.until) setUntil(toLocal(rule.options.until))
      if (rule.options.count) setCount(String(rule.options.count))
    } catch (_) {
      // ignora string inválida
    }
  }, [value])

  const weekdays = [
    { key: 'MO', label: 'Seg' },
    { key: 'TU', label: 'Ter' },
    { key: 'WE', label: 'Qua' },
    { key: 'TH', label: 'Qui' },
    { key: 'FR', label: 'Sex' },
    { key: 'SA', label: 'Sáb' },
    { key: 'SU', label: 'Dom' },
  ]

  const freqMap = {
    DAILY: RRule.DAILY,
    WEEKLY: RRule.WEEKLY,
    MONTHLY: RRule.MONTHLY,
    YEARLY: RRule.YEARLY,
  }

  const rruleString = useMemo(() => {
    if (!enabled) return ''

    const options = {
      freq: freqMap[freq] ?? RRule.WEEKLY,
      interval: Number(interval) || 1,
    }

    if (byday?.length) {
      options.byweekday = byday.map((d) => RRule[d])
    }

    if (dtstart) options.dtstart = new Date(dtstart)
    if (until) options.until = new Date(until)
    if (count) options.count = Number(count)

    try {
      const rule = new RRule(options)
      return rule.toString()
    } catch (e) {
      return ''
    }
  }, [enabled, freq, interval, byday, dtstart, until, count])

  useEffect(() => {
    onChange && onChange(rruleString)
  }, [rruleString, onChange])

  const nextDates = useMemo(() => {
    if (!rruleString) return []
    try {
      const rule = RRule.fromString(rruleString)
      return rule.all((date, i) => i < 5)
    } catch (_) {
      return []
    }
  }, [rruleString])

  const toggleDay = (k) => {
    setByday((prev) => (prev.includes(k) ? prev.filter((d) => d !== k) : [...prev, k]))
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <input id="recorrente" type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
        <label htmlFor="recorrente" className="text-sm font-medium text-slate-700">Lembrete recorrente</label>
      </div>

      {enabled && (
        <div className="space-y-4 rounded-2xl border p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700">Frequência</label>
              <select
                className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
                value={freq}
                onChange={(e) => setFreq(e.target.value)}
              >
                <option value="DAILY">Diário</option>
                <option value="WEEKLY">Semanal</option>
                <option value="MONTHLY">Mensal</option>
                <option value="YEARLY">Anual</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">Intervalo</label>
              <input
                type="number"
                min={1}
                className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
                value={interval}
                onChange={(e) => setInterval(Number(e.target.value) || 1)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">DTSTART</label>
              <input
                type="datetime-local"
                className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
                value={dtstart}
                onChange={(e) => setDtstart(e.target.value)}
              />
            </div>
          </div>

          {freq === 'WEEKLY' && (
            <div>
              <label className="block text-sm font-medium text-slate-700">Dias da semana</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {weekdays.map((w) => (
                  <button
                    type="button"
                    key={w.key}
                    className={`px-3 py-1 rounded-full border ${byday.includes(w.key) ? 'bg-violet-600 text-white border-violet-600' : 'border-slate-300'}`}
                    onClick={() => toggleDay(w.key)}
                  >
                    {w.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700">UNTIL (opcional)</label>
              <input
                type="datetime-local"
                className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
                value={until}
                onChange={(e) => setUntil(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700">COUNT (opcional)</label>
              <input
                type="number"
                min={1}
                className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
                value={count}
                onChange={(e) => setCount(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700">RRULE gerada</label>
            <input
              type="text"
              readOnly
              className="mt-1 w-full rounded-xl border border-slate-300 p-2 bg-slate-50 font-mono text-sm"
              value={rruleString}
            />
            <p className="text-xs text-slate-500 mt-1">Pré-visualização das próximas 5 ocorrências:</p>
            <ul className="mt-1 text-sm list-disc list-inside space-y-1">
              {nextDates.map((d, i) => (
                <li key={i}>{fmt(d)}</li>
              ))}
              {!nextDates.length && <li>Nenhuma ocorrência calculada.</li>}
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}

function toLocal(date) {
  const pad = (n) => String(n).padStart(2, '0')
  const yyyy = date.getFullYear()
  const mm = pad(date.getMonth() + 1)
  const dd = pad(date.getDate())
  const hh = pad(date.getHours())
  const mi = pad(date.getMinutes())
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}`
}

function fmt(date) {
  return new Intl.DateTimeFormat('pt-BR', {
    dateStyle: 'short',
    timeStyle: 'short',
  }).format(date)
}
