import { useEffect, useMemo, useState } from 'react'

export default function PayloadBuilder({ value, onChange }) {
  const [assunto, setAssunto] = useState('')
  const [mensagem, setMensagem] = useState('')
  const [anexos, setAnexos] = useState([])
  const [novoAnexo, setNovoAnexo] = useState('')
  const [extras, setExtras] = useState([{ chave: '', valor: '' }])

  // Hidratar a partir de value (se vier JSON válido)
  useEffect(() => {
    if (!value) return
    try {
      const parsed = JSON.parse(value)
      setAssunto(parsed.assunto || '')
      setMensagem(parsed.mensagem || '')
      setAnexos(Array.isArray(parsed.anexos) ? parsed.anexos : [])
      const exts = parsed.extras && Array.isArray(parsed.extras)
        ? parsed.extras.map(([chave, valor]) => ({ chave, valor }))
        : [{ chave: '', valor: '' }]
      setExtras(exts)
    } catch {}
  }, [value])

  // Monta JSON final (nos bastidores) e envia via onChange apenas se mudou
  const jsonFinal = useMemo(() => {
    const extrasKV = extras.filter(e => e.chave).map(e => [e.chave, e.valor])
    const payload = {
      assunto: assunto || undefined,
      mensagem: mensagem || '',
      anexos: anexos.length ? anexos : undefined,
      extras: extrasKV.length ? extrasKV : undefined,
    }
    return JSON.stringify(JSON.parse(JSON.stringify(payload)), null, 2)
  }, [assunto, mensagem, anexos, extras])

  useEffect(() => {
    if (!onChange) return
    if ((value || '').trim() === (jsonFinal || '').trim()) return
    onChange(jsonFinal)
  }, [jsonFinal, onChange, value])

  const addAnexo = () => {
    if (!novoAnexo.trim()) return
    setAnexos(prev => [...prev, novoAnexo.trim()])
    setNovoAnexo('')
  }
  const removeAnexo = (i) => setAnexos(prev => prev.filter((_, idx) => idx !== i))

  const addExtra = () => setExtras(prev => [...prev, { chave: '', valor: '' }])
  const updateExtra = (i, field, val) => setExtras(prev => prev.map((ex, idx) => (idx === i ? { ...ex, [field]: val } : ex)))
  const removeExtra = (i) => setExtras(prev => prev.filter((_, idx) => idx !== i))

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-slate-700">Título da mensagem</label>
        <input
          type="text"
          className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
          placeholder="Ex.: Cobrança do serviço mensal"
          value={assunto}
          onChange={(e) => setAssunto(e.target.value)}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700">Corpo da mensagem</label>
        <textarea
          className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500 min-h-[120px]"
          placeholder="Você pode usar campos automáticos como {{cliente.nome}} e {{cliente.primeiro_nome}}."
          value={mensagem}
          onChange={(e) => setMensagem(e.target.value)}
        />
        <p className="text-xs text-slate-500 mt-1">
          Campos automáticos: {'{{cliente.nome}}'}, {'{{cliente.primeiro_nome}}'} e os “Campos adicionais” abaixo.
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700">Anexos (URLs) — opcional</label>
        <div className="flex items-center gap-2 mt-1">
          <input
            type="url"
            className="flex-1 rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
            placeholder="https://..."
            value={novoAnexo}
            onChange={(e) => setNovoAnexo(e.target.value)}
          />
          <button type="button" className="rounded-xl border px-3 py-2 hover:bg-slate-50" onClick={addAnexo}>
            Adicionar
          </button>
        </div>
        {!!anexos.length && (
          <ul className="mt-2 space-y-1 text-sm">
            {anexos.map((a, i) => (
              <li key={`${a}-${i}`} className="flex items-center justify-between rounded-lg border p-2">
                <span className="truncate">{a}</span>
                <button type="button" className="text-red-600 text-xs" onClick={() => removeAnexo(i)}>
                  Remover
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700">Campos adicionais (preenchidos automaticamente)</label>
        <div className="mt-2 space-y-2">
          {extras.map((ex, i) => (
            <div key={i} className="grid grid-cols-5 gap-2">
              <input
                type="text"
                className="col-span-2 rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
                placeholder="chave (ex.: valor_da_fatura)"
                value={ex.chave}
                onChange={(e) => updateExtra(i, 'chave', e.target.value)}
              />
              <input
                type="text"
                className="col-span-2 rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
                placeholder="valor (ex.: 199.90)"
                value={ex.valor}
                onChange={(e) => updateExtra(i, 'valor', e.target.value)}
              />
              <div className="col-span-1 flex items-center justify-end">
                <button type="button" className="text-red-600 text-xs" onClick={() => removeExtra(i)}>
                  Remover
                </button>
              </div>
            </div>
          ))}
          <button type="button" className="rounded-xl border px-3 py-2 hover:bg-slate-50" onClick={addExtra}>
            + Adicionar campo
          </button>
        </div>
      </div>
    </div>
  )
}
