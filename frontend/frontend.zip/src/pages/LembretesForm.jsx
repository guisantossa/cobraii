import { useEffect, useState } from 'react'
import TipoSelect from '../components/Reminders/TipoSelect'
import PayloadBuilder from '../components/Reminders/PayloadBuilder'
import RRuleBuilder from '../components/Reminders/RRuleBuilder'
import api from '../services/api'

export default function LembretesForm({ aberto, lembrete, onSalvar, onFechar }) {
  const [form, setForm] = useState({
    titulo: '',
    tipo: 'whatsapp',
    tipo_outros_desc: '',
    payload: '', // string JSON
    rrule: '',   // string RRULE (opcional)
  })
  const [loading, setLoading] = useState(false)
  const [erro, setErro] = useState('')

  useEffect(() => {
    if (lembrete) {
      setForm({
        titulo: lembrete.titulo || '',
        tipo: lembrete.tipo || 'whatsapp',
        tipo_outros_desc: lembrete.tipo_outros_desc || '',
        payload: typeof lembrete.payload === 'string' ? lembrete.payload : JSON.stringify(lembrete.payload || {}, null, 2),
        rrule: lembrete.rrule || '',
      })
    } else {
      setForm({ titulo: '', tipo: 'whatsapp', tipo_outros_desc: '', payload: '', rrule: '' })
    }
  }, [lembrete])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErro('')

    if (!form.titulo.trim()) {
      setErro('Informe um título para o lembrete.')
      return
    }

    try {
      if (form.payload && typeof form.payload === 'string') JSON.parse(form.payload)
    } catch (err) {
      setErro('Payload não é um JSON válido.')
      return
    }

    const body = {
      titulo: form.titulo,
      tipo: form.tipo,
      payload: form.payload, // backend já aceita string JSON
      rrule: form.rrule || null,
    }

    if (form.tipo === 'outros' && form.tipo_outros_desc.trim()) {
      try {
        const parsed = form.payload ? JSON.parse(form.payload) : {}
        parsed.tipo_outros_desc = form.tipo_outros_desc.trim()
        body.payload = JSON.stringify(parsed)
      } catch (_) {}
    }

    try {
      setLoading(true)
      let resp
      if (lembrete?.id) {
        resp = await api.put(`/api/v1/lembretes/${lembrete.id}`, body)
      } else {
        resp = await api.post(`/api/v1/lembretes`, body)
      }
      onSalvar && onSalvar(resp.data)
    } catch (err) {
      console.error(err)
      setErro('Falha ao salvar o lembrete. Verifique os campos e tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h2 className="text-xl font-semibold text-slate-800 mb-4">Novo Lembrete</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700">Título</label>
          <input
            type="text"
            className="mt-1 w-full rounded-xl border border-slate-300 p-2 focus:outline-none focus:ring-2 focus:ring-violet-500"
            placeholder="Ex.: Cobrança de manutenção"
            value={form.titulo}
            onChange={(e) => setForm((f) => ({ ...f, titulo: e.target.value }))}
          />
        </div>

        <TipoSelect
          value={form.tipo}
          onChange={(v) => setForm((f) => ({ ...f, tipo: v }))}
          outroDescricao={form.tipo_outros_desc}
          onOutroDescricaoChange={(v) => setForm((f) => ({ ...f, tipo_outros_desc: v }))}
        />

        <div>
          <label className="block text-sm font-medium text-slate-700">Payload</label>
          <PayloadBuilder
            value={form.payload}
            onChange={(jsonStr) => setForm((f) => (f.payload === jsonStr ? f : { ...f, payload: jsonStr }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700">Recorrência (RRULE)</label>
          <RRuleBuilder
            value={form.rrule}
            onChange={(r) => setForm((f) => (f.rrule === r ? f : { ...f, rrule: r }))}
          />
        </div>

        {erro && <p className="text-sm text-red-600">{erro}</p>}

        <div className="flex justify-end gap-2">
          <button
            type="button"
            className="rounded-xl border px-4 py-2 hover:bg-slate-50"
            onClick={() => onFechar && onFechar()}
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={loading}
            className="rounded-xl bg-[#5E2CA5] text-white px-4 py-2 hover:opacity-90 disabled:opacity-60"
          >
            {loading ? 'Salvando...' : 'Salvar lembrete'}
          </button>
        </div>
      </form>
    </div>
  )
}
