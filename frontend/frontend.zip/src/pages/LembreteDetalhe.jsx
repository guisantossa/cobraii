import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { getLembrete, patchEstadoLembrete, listarOcorrencias, deleteLembrete } from "../services/lembretes";

export default function LembreteDetalhe() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [item, setItem] = useState(null);
  const [occs, setOccs] = useState({ items: [], page: 1, total: 0 });

  const load = async () => {
    try {
      const data = await getLembrete(id);
      setItem(data);
      const oc = await listarOcorrencias(id, { page: 1, page_size: 20 });
      setOccs(oc);
    } catch (e) {
      console.error(e);
      alert("Falha ao carregar");
    }
  };

  useEffect(() => { load(); }, [id]);

  const onEstado = async (acao) => {
    if (!confirm(`Confirmar ${acao}?`)) return;
    await patchEstadoLembrete(id, acao);
    await load();
  };

  const onExcluir = async () => {
    if (!confirm("Excluir lembrete?")) return;
    await deleteLembrete(id);
    navigate("/lembretes");
  };

  if (!item) return <div className="p-4">Carregando...</div>;

  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">{item.titulo || "(sem título)"}</h1>
          <p className="text-sm text-slate-500">Tipo: {item.tipo} • Estado: {item.estado}</p>
        </div>
        <div className="flex gap-2">
          {item.estado === "agendado" && (
            <button onClick={()=>onEstado("pausar")} className="px-3 py-2 rounded bg-amber-600 text-white">Pausar</button>
          )}
          {item.estado === "pausado" && (
            <button onClick={()=>onEstado("retomar")} className="px-3 py-2 rounded bg-green-600 text-white">Retomar</button>
          )}
          {item.estado !== "cancelado" && (
            <button onClick={()=>onEstado("cancelar")} className="px-3 py-2 rounded bg-red-600 text-white">Cancelar</button>
          )}
          <Link to={`/lembretes/${id}/editar`} className="px-3 py-2 rounded bg-slate-600 text-white">Editar</Link>
          <button onClick={onExcluir} className="px-3 py-2 rounded bg-red-700 text-white">Excluir</button>
        </div>
      </div>

      <section className="bg-white rounded shadow p-4">
        <h2 className="font-medium mb-3">Canais</h2>
        <ul className="text-sm space-y-1">
          {item.canais.map(c => (
            <li key={c.id}>{c.ordem}. {c.canal} {c.habilitado ? "(on)" : "(off)"}</li>
          ))}
        </ul>
      </section>

      <section className="bg-white rounded shadow p-4">
        <h2 className="font-medium mb-3">Destinatários</h2>
        <ul className="text-sm space-y-1">
          {item.destinatarios.map(d => (
            <li key={d.id}>
              {d.cliente_id ? (
                <>Cliente: {d.cliente_id}</>
              ) : (
                <>Avulso: {d.contato_avulso?.nome} • {d.contato_avulso?.telefone || "—"} • {d.contato_avulso?.email || "—"}</>
              )}
            </li>
          ))}
        </ul>
      </section>

      <section className="bg-white rounded shadow p-4">
        <h2 className="font-medium mb-3">Ocorrências</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="text-left p-2">Data Programada</th>
                <th className="text-left p-2">Status</th>
                <th className="text-left p-2">Canal usado</th>
                <th className="text-left p-2">Tentativas</th>
                <th className="text-left p-2">Último erro</th>
              </tr>
            </thead>
            <tbody>
              {occs.items.map(o => (
                <tr key={o.id} className="border-t">
                  <td className="p-2">{new Date(o.dt_programada).toLocaleString()}</td>
                  <td className="p-2">{o.status}</td>
                  <td className="p-2">{o.canal_usado || "—"}</td>
                  <td className="p-2">{o.tentativas}</td>
                  <td className="p-2">{o.ultimo_erro || "—"}</td>
                </tr>
              ))}
              {!occs.items.length && (
                <tr><td className="p-4" colSpan={5}>Sem ocorrências.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}