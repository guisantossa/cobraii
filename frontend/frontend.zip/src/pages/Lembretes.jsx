import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { listLembretes } from "../services/lembretes";

export default function Lembretes() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({ items: [], page: 1, total: 0 });
  const [filters, setFilters] = useState({ tipo: "", estado: "" });
  const navigate = useNavigate();

  const load = async () => {
    setLoading(true);
    try {
      const res = await listLembretes({ page: 1, page_size: 20, ...filters });
      setData(res);
    } catch (e) {
      console.error(e);
      alert("Falha ao listar lembretes");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const onFilter = async (e) => {
    e.preventDefault();
    load();
  };

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold">Lembretes</h1>
        <button onClick={() => navigate("/lembretes/novo")} className="px-3 py-2 rounded bg-blue-600 text-white hover:bg-blue-700">
          + Novo Lembrete
        </button>
      </div>

      <form onSubmit={onFilter} className="flex gap-2 items-end mb-4">
        <div>
          <label className="block text-sm">Tipo</label>
          <select className="border rounded px-2 py-1" value={filters.tipo}
                  onChange={(e) => setFilters({ ...filters, tipo: e.target.value })}>
            <option value="">Todos</option>
            <option value="cobranca">Cobrança</option>
            <option value="documento">Documento</option>
            <option value="agendamento">Agendamento</option>
            <option value="aviso">Aviso</option>
          </select>
        </div>
        <div>
          <label className="block text-sm">Estado</label>
          <select className="border rounded px-2 py-1" value={filters.estado}
                  onChange={(e) => setFilters({ ...filters, estado: e.target.value })}>
            <option value="">Todos</option>
            <option value="agendado">Agendado</option>
            <option value="pausado">Pausado</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>
        <button type="submit" className="px-3 py-2 rounded bg-slate-600 text-white">Filtrar</button>
      </form>

      {loading ? (
        <div>Carregando...</div>
      ) : (
        <div className="overflow-x-auto bg-white rounded shadow">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="text-left p-2">Título</th>
                <th className="text-left p-2">Tipo</th>
                <th className="text-left p-2">Estado</th>
                <th className="text-left p-2">Próxima Execução</th>
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((it) => (
                <tr key={it.id} className="border-t">
                  <td className="p-2">{it.titulo || "—"}</td>
                  <td className="p-2">{it.tipo}</td>
                  <td className="p-2">{it.estado}</td>
                  <td className="p-2">{it.proxima_execucao ? new Date(it.proxima_execucao).toLocaleString() : "—"}</td>
                  <td className="p-2 text-right">
                    <Link className="text-blue-600 hover:underline" to={`/lembretes/${it.id}`}>Abrir</Link>
                  </td>
                </tr>
              ))}
              {!data.items.length && (
                <tr><td className="p-4" colSpan={5}>Nenhum lembrete encontrado.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
